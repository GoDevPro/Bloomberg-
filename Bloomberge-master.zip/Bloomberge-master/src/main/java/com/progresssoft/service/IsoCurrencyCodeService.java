package com.progresssoft.service;

import java.util.Map;

import com.progresssoft.bean.IsoCurrecncyCodeBean;

public interface IsoCurrencyCodeService {

	public Map<String,IsoCurrecncyCodeBean> getAllIsoCurrencyCodes();
	
	
}
