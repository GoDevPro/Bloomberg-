package com.progresssoft.dao;

import java.util.Map;

import com.progresssoft.bean.IsoCurrecncyCodeBean;

public interface IsoCurrencyCodeDao {
	
	public Map<String,IsoCurrecncyCodeBean> getAllIsoCurrencyCodes();
}
